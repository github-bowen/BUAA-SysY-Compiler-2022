#ifndef THIS_PROJECT_VAR_CONST_H
#define THIS_PROJECT_VAR_CONST_H

class VarConst {
public:
    const int value;
    explicit VarConst(int value) : value(value) {}
};

#endif //THIS_PROJECT_VAR_CONST_H
