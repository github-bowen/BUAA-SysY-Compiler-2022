#ifndef GENERAL_DEBUG_SWITCH
#define GENERAL_DEBUG_SWITCH

#define NDEBUG
#include <cassert>

//#define PARSER_DEBUG  // Parser.cpp
//#define ERROR_HANDLER_DEBUG  // ErrorHandler.cpp
//#define NODE_DEBUG  // Node.cpp
#define I_C_TRANSLATOR_DEBUG  // ICTranslator.cpp

#endif //GENERAL_DEBUG_SWITCH
