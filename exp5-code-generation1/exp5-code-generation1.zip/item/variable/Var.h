#ifndef THIS_PROJECT_VAR_H
#define THIS_PROJECT_VAR_H

class Var {
public:
    int value;

    Var() = default;
    Var(int value) : value(value) {}
};

#endif //THIS_PROJECT_VAR_H
